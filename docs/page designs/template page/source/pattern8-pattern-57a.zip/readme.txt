Thanks for downloading this file from http://pattern8.com

You're free to use the contents of the download within the terms of use.

Please visit http://pattern8.com/terms-of-use for full terms and conditions. 

